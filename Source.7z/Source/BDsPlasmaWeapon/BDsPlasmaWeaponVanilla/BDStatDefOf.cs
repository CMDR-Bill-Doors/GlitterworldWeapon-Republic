﻿using Verse;
using RimWorld;

namespace BDsPlasmaWeaponVanilla
{
    [DefOf]
    public static class BDStatDefOf
    {
        public static EffecterDef LizionPipeLeakMajor;
        public static EffecterDef LizionCoolerLow;
        public static EffecterDef LizionCoolerHigh;
    }
}
