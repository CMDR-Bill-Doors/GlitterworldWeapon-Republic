﻿using RimWorld;
using Verse;

namespace BDsPlasmaWeapon
{


    [DefOf]
    public static class StatDefOf
    {
        public static StatDef BDP_LizionHeatShieldEfficiency;

        public static StatDef BDP_LizionHeatShieldHiccupChance;
    }
}


