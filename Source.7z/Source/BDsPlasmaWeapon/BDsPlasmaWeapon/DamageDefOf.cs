﻿using RimWorld;
using Verse;

namespace BDsPlasmaWeapon
{


    [DefOf]
    public static class DamageDefOf
    {
        public static DamageDef LizionExplosion;
    }
}


