﻿using System.Collections.Generic;
using PipeSystem;
using RimWorld;
using UnityEngine;
using Verse;
using System;
using Verse.Sound;
using Verse.AI;
using CombatExtended;
using System.Runtime.Remoting.Messaging;
using CombatExtended.Compatibility;
using System.Linq;

namespace BDsPlasmaWeapon
{
    public class CompDropExtinguisherWhenUndrafted : CompRangedGizmoGiver
    {
        public DropLogic dropLogic;

        CompReloadableFromFiller compTank;

        CompEquippable compEquippable;

        public CompProperties_DropExtinguisherWhenUndrafted Props
        {
            get
            {
                return (CompProperties_DropExtinguisherWhenUndrafted)props;
            }
        }

        public bool isEquipment => compEquippable != null;

        public bool isApparel => parent is Apparel;

        public Pawn pawn
        {
            get
            {
                if (isEquipment)
                {
                    return compEquippable.PrimaryVerb.CasterPawn;
                }
                if (isApparel)
                {
                    return (parent as Apparel).Wearer;
                }
                return null;
            }
        }
        public void switchMode(DropLogic DropLogic)
        {
            dropLogic = DropLogic;
        }

        public override void PostSpawnSetup(bool respawningAfterLoad)
        {
            base.PostSpawnSetup(respawningAfterLoad);
            compTank = parent.TryGetComp<CompReloadableFromFiller>();
            compEquippable = parent.TryGetComp<CompEquippable>();
            if (compTank == null)
            {
                Log.Error("CompDropExtinguisherWhenUndrafted is meant to work with CompReloadableFromFiller!");
            }
            if (!respawningAfterLoad)
            {
                dropLogic = Props.defaultDropLogic;
            }
        }


        public bool shouldDrop
        {
            get
            {
                if (pawn != null || !pawn.Drafted)
                {
                    switch (dropLogic)
                    {
                        case DropLogic.DontDrop:
                            return false;
                        case DropLogic.AlwaysDrop:
                            return true;
                        case DropLogic.DropWhenEmpty:
                            if (compTank.remainingCharges == 0)
                            {
                                return true;
                            }
                            return false;
                        case DropLogic.DropWhenFull:
                            if (compTank.emptySpace == 0)
                            {
                                return true;
                            }
                            return false;
                        case DropLogic.DropIfNotFull:
                            if (compTank.emptySpace > 0)
                            {
                                return true;
                            }
                            return false;
                        default:
                            return false;
                    }
                }
                return false;
            }
        }

        private string getIconTex(DropLogic dropLogic)
        {
            switch (dropLogic)
            {
                case DropLogic.DontDrop:
                    return Props.DontDropIcon;
                case DropLogic.AlwaysDrop:
                    return Props.AlwaysDropIcon;
                case DropLogic.DropWhenEmpty:
                    return Props.DropWhenEmptyIcon;
                case DropLogic.DropWhenFull:
                    return Props.DropWhenFullIcon;
                case DropLogic.DropIfNotFull:
                    return Props.DropIfNotFullIcon;
                default:
                    return "UI/Commands/DesirePower";
            }
        }

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            if (parent != null && !parent.Faction.Equals(Faction.OfPlayer))
            {
                yield break;
            }
            yield return new Command_SwitchDropLogic
            {
                compExtinguisher = this,
                defaultLabel = "none",
                defaultDesc = Props.description,
                icon = ContentFinder<Texture2D>.Get(getIconTex(dropLogic)),
            };
            yield break;
        }
    }

    public class CompProperties_DropExtinguisherWhenUndrafted : CompProperties
    {
        public DropLogic defaultDropLogic = DropLogic.DontDrop;
        public string DontDropIcon = "UI/Commands/DesirePower";
        public string DropWhenEmptyIcon = "UI/Commands/DesirePower";
        public string DropIfNotFullIcon = "UI/Commands/DesirePower";
        public string DropWhenFullIcon = "UI/Commands/DesirePower";
        public string AlwaysDropIcon = "UI/Commands/DesirePower";
        public string description = "UI/Commands/DesirePower";
        public string label = "Drop logic";
        public CompProperties_DropExtinguisherWhenUndrafted()
        {
            compClass = typeof(CompDropExtinguisherWhenUndrafted);
        }
    }

    public enum DropLogic : byte
    {
        DontDrop,
        DropWhenEmpty,
        DropIfNotFull,
        DropWhenFull,
        AlwaysDrop,
    }

    public class Command_SwitchDropLogic : Command_Action
    {
        private List<Command_SwitchDropLogic> others;

        public CompDropExtinguisherWhenUndrafted compExtinguisher;

        public override bool GroupsWith(Gizmo other)
        {
            Command_SwitchDropLogic command_Reload = other as Command_SwitchDropLogic;
            return command_Reload != null;
        }

        public override void MergeWith(Gizmo other)
        {
            Command_SwitchDropLogic item = other as Command_SwitchDropLogic;
            if (others == null)
            {
                others = new List<Command_SwitchDropLogic>();
                others.Add(this);
            }
            others.Add(item);
        }

        public override void ProcessInput(Event ev)
        {
            if (compExtinguisher.pawn.TryGetComp<CompInventory>() != null)
            {
                Find.WindowStack.Add(MakeAmmoMenu());
            }
        }

        private FloatMenu MakeAmmoMenu()
        {
            return new FloatMenu(BuildAmmoOptions());
        }

        private List<FloatMenuOption> BuildAmmoOptions()
        {
            List<FloatMenuOption> list = new List<FloatMenuOption>();
            Action action1 = delegate
            {
                compExtinguisher.switchMode(DropLogic.DontDrop);
            };
            Action action2 = delegate
            {
                compExtinguisher.switchMode(DropLogic.AlwaysDrop);
            };
            Action action3 = delegate
            {
                compExtinguisher.switchMode(DropLogic.DropIfNotFull);
            };
            Action action4 = delegate
            {
                compExtinguisher.switchMode(DropLogic.DropWhenFull);
            };
            Action action5 = delegate
            {
                compExtinguisher.switchMode(DropLogic.DropWhenEmpty);
            };

            list.Add(new FloatMenuOption("dontDrop".Translate(), action1));
            list.Add(new FloatMenuOption("alwaysDrop".Translate(), action2));
            list.Add(new FloatMenuOption("dropIfNotFull".Translate(), action3));
            list.Add(new FloatMenuOption("dropWhenFull".Translate(), action4));
            list.Add(new FloatMenuOption("dropWhenEmpty".Translate(), action5));
            return list;
        }
    }
}
