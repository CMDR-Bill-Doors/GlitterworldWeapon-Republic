﻿using RimWorld;
using Verse;

namespace BDsPlasmaWeapon
{


    [DefOf]
    public static class JobDefOf
    {
        public static JobDef BDP_JobDefRefillFromFiller;

        public static JobDef BDP_FlickLizionCooler;
    }
}
