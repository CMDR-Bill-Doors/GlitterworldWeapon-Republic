﻿using RimWorld;
using Verse;

namespace BDsPlasmaWeapon
{


    [DefOf]
    public static class DamageArmorCategoryDefOf
    {
        public static DamageArmorCategoryDef Heat;
    }
}
